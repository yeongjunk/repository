using Fermions
using Random, LinearAlgebra, SparseArrays
function test_quadratic(; verbose = false)
    flag = true
    for L in 4:10
        for R in 1:30
            basis = get_basis(L)
            i = rand(1:L)
            j = rand(1:L)
            h1 = c_adj(1.0, i, basis, sorted = true)
            h2 = c_adj(1.0, j, basis, sorted = true)'
            h = h1*h2;

            g = c_adj_c(1.0, i, j, basis, sorted = true)
            if verbose 
                println("L = $(L), i = $(i), j = $(j) : ", all(h .== g))
            end
            flag = flag && all(h .== g)
        end
    end
    return flag
end

function test_quartic(; verbose = false, rng = Random.GLOBAL_RNG)
    flag = true
    for L in 5:8
        for r in 1:30
            basis = get_basis(L)
            i, j, k, l = rand(rng, 1:L), rand(rng, 1:L), rand(rng, 1:L), rand(rng, 1:L)

            h1 = c_adj_c(1.0, i, k, basis, sorted = true)
            h2 = c_adj_c(1.0, j, l, basis, sorted = true)

            h = h1*h2;
            g = -c_adj_c_adj_c_c(1.0, i, j, k, l, basis, sorted = true)
            hh = g - h

            if j == k
                g += c_adj_c(1.0, i, l, basis, sorted = true)
            end

            if verbose 
                println("L = $(L), i = $(i), j = $(j), k = $(k), l = $(l) : ", all(h .== g))
            end
            flag = flag && all(h .== g)
        end
    end
    return flag
end

function test_large()
    L = 255
    basis = sort(get_basis(L, 2));
    r, c, v = Int64[], Int64[], Float64[]
    for i in 1:L
        c_adj_c!(r, c, v, 1.0, i, mod1(i+1, L), basis; sorted = true)
        c_adj_c!(r, c, v, 1.0, mod1(i+1, L), i, basis; sorted = true)
    end
    H = sparse(r, c, v, length(basis), length(basis))
    
    return true
end

@time if test_quadratic() && test_quartic() && test_large()
    println("Test successful")
else
    println("Test faild")
end
